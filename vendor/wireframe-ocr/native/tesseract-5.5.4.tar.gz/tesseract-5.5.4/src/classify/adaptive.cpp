/******************************************************************************
 ** Filename:    adaptive.c
 ** Purpose:     Adaptive matcher.
 ** Author:      Dan Johnson
 **
 ** (c) Copyright Hewlett-Packard Company, 1988.
 ** Licensed under the Apache License, Version 2.0 (the "License");
 ** you may not use this file except in compliance with the License.
 ** You may obtain a copy of the License at
 ** http://www.apache.org/licenses/LICENSE-2.0
 ** Unless required by applicable law or agreed to in writing, software
 ** distributed under the License is distributed on an "AS IS" BASIS,
 ** WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 ** See the License for the specific language governing permissions and
 ** limitations under the License.
 ******************************************************************************/

#include "adaptive.h"

#include "classify.h"
#include "tesserrstream.h" // for tesserr

#include <cassert>
#include <cstdio>

namespace tesseract {

/*----------------------------------------------------------------------------
              Public Code
----------------------------------------------------------------------------*/
/*---------------------------------------------------------------------------*/
/**
 * This routine adds a new adapted class to an existing
 * set of adapted templates.
 *
 * @param Templates set of templates to add new class to
 * @param Class new class to add to templates
 * @param ClassId class id to associate with new class
 *
 * @note Globals: none
 */
bool AddAdaptedClass(ADAPT_TEMPLATES_STRUCT *Templates, ADAPT_CLASS_STRUCT *Class, CLASS_ID ClassId) {
  assert(Templates != nullptr);
  assert(Class != nullptr);
  assert(Class->NumPermConfigs == 0);

  // ClassId indexes the fixed-size Templates->Class[] array, so reject an
  // out-of-range id instead of writing out of bounds below.
  if (!LegalClassId(ClassId)) {
    tesserr << "Error: illegal class id " << ClassId << " in AddAdaptedClass\n";
    delete Class;
    return false;
  }

  auto IntClass = new INT_CLASS_STRUCT(1);
  if (!AddIntClass(Templates->Templates, ClassId, IntClass)) {
    delete IntClass;
    delete Class;
    return false;
  }

  assert(Templates->Class[ClassId] == nullptr);
  Templates->Class[ClassId] = Class;

  return true;
} /* AddAdaptedClass */

/*---------------------------------------------------------------------------*/

PERM_CONFIG_STRUCT::~PERM_CONFIG_STRUCT() {
  delete[] Ambigs;
}

ADAPT_CLASS_STRUCT::ADAPT_CLASS_STRUCT() :
  NumPermConfigs(0),
  MaxNumTimesSeen(0),
  PermProtos(NewBitVector(MAX_NUM_PROTOS)),
  PermConfigs(NewBitVector(MAX_NUM_CONFIGS)),
  TempProtos(NIL_LIST) {
  zero_all_bits(PermProtos, WordsInVectorOfSize(MAX_NUM_PROTOS));
  zero_all_bits(PermConfigs, WordsInVectorOfSize(MAX_NUM_CONFIGS));
}

ADAPT_CLASS_STRUCT::~ADAPT_CLASS_STRUCT() {
  for (int i = 0; i < MAX_NUM_CONFIGS; i++) {
    if (ConfigIsPermanent(this, i) && PermConfigFor(this, i) != nullptr) {
      delete PermConfigFor(this, i);
    } else if (!ConfigIsPermanent(this, i) && TempConfigFor(this, i) != nullptr) {
      delete TempConfigFor(this, i);
    }
  }
  FreeBitVector(PermProtos);
  FreeBitVector(PermConfigs);
  auto list = TempProtos;
  while (list != nullptr) {
    delete reinterpret_cast<TEMP_PROTO_STRUCT *>(list->node);
    list = pop(list);
  }
}

/// Constructor for adapted templates.
/// Add an empty class for each char in unicharset to the newly created templates.
/// The unicharset must not have more than MAX_NUM_CLASSES entries, as a unichar
/// id indexes the fixed-size class arrays. If it does, the construction fails:
/// the object is left unusable and valid() returns false, so callers have to
/// check it.
ADAPT_TEMPLATES_STRUCT::ADAPT_TEMPLATES_STRUCT(UNICHARSET &unicharset) :
  Templates(new INT_TEMPLATES_STRUCT), NumNonEmptyClasses(0), NumPermClasses(0) {
  // Insert an empty class for each unichar id in unicharset.
  // Class is value-initialized to nullptr in-class.
  for (unsigned i = 0; i < unicharset.size(); i++) {
    if (!AddAdaptedClass(this, new ADAPT_CLASS_STRUCT, i)) {
      // A rejected ClassId i means the classes 0..NumClasses-1 were stored
      // successfully. The destructor skips the Class[] cleanup once Templates
      // is set to nullptr below, so free them here.
      for (unsigned j = 0; j < Templates->NumClasses; j++) {
        delete Class[j];
      }
      delete Templates;
      Templates = nullptr;
      return;
    }
  }
}

ADAPT_TEMPLATES_STRUCT::~ADAPT_TEMPLATES_STRUCT() {
  if (Templates != nullptr) {
    // NumClasses comes from an untrusted file, so never trust it to bound
    // the loop over the fixed-size Class[] array.
    for (unsigned i = 0; i < (Templates)->NumClasses && i < MAX_NUM_CLASSES; i++) {
      delete Class[i];
    }
    delete Templates;
  }
}

// Returns FontinfoId of the given config of the given adapted class.
int Classify::GetFontinfoId(ADAPT_CLASS_STRUCT *Class, uint8_t ConfigId) {
  return (ConfigIsPermanent(Class, ConfigId) ? PermConfigFor(Class, ConfigId)->FontinfoId
                                             : TempConfigFor(Class, ConfigId)->FontinfoId);
}

/// This constructor allocates and returns a new temporary config.
///
/// @param MaxProtoId  max id of any proto in new config
/// @param FontinfoId font information from pre-trained templates
TEMP_CONFIG_STRUCT::TEMP_CONFIG_STRUCT(int maxProtoId, int fontinfoId) :
  NumTimesSeen(1),
  ProtoVectorSize(WordsInVectorOfSize(maxProtoId + 1)),
  MaxProtoId(maxProtoId),
  Protos(NewBitVector(maxProtoId + 1)),
  FontinfoId(fontinfoId) {
  zero_all_bits(Protos, ProtoVectorSize);
}

TEMP_CONFIG_STRUCT::~TEMP_CONFIG_STRUCT() {
  FreeBitVector(Protos);
}

/*---------------------------------------------------------------------------*/
/**
 * This routine prints a summary of the adapted templates
 *  in Templates to File.
 *
 * @param File    open text file to print Templates to
 * @param Templates adapted templates to print to File
 *
 * @note Globals: none
 */
void Classify::PrintAdaptedTemplates(FILE *File, ADAPT_TEMPLATES_STRUCT *Templates) {
  INT_CLASS_STRUCT *IClass;
  ADAPT_CLASS_STRUCT *AClass;

  fprintf(File, "\n\nSUMMARY OF ADAPTED TEMPLATES:\n\n");
  fprintf(File, "Num classes = %d;  Num permanent classes = %d\n\n", Templates->NumNonEmptyClasses,
          Templates->NumPermClasses);
  fprintf(File, "   Id  NC NPC  NP NPP\n");
  fprintf(File, "------------------------\n");

  for (unsigned i = 0; i < (Templates->Templates)->NumClasses; i++) {
    IClass = Templates->Templates->Class[i];
    AClass = Templates->Class[i];
    if (!IsEmptyAdaptedClass(AClass)) {
      fprintf(File, "%5u  %s %3d %3d %3d %3zd\n", i, unicharset.id_to_unichar(i), IClass->NumConfigs,
              AClass->NumPermConfigs, IClass->NumProtos,
              IClass->NumProtos - AClass->TempProtos->size());
    }
  }
  fprintf(File, "\n");

} /* PrintAdaptedTemplates */

/*---------------------------------------------------------------------------*/
/**
 * Read an adapted class description from file and return
 * a ptr to the adapted class.
 *
 * @param fp open file to read adapted class from
 * @return Ptr to new adapted class.
 *
 * @note Globals: none
 */
ADAPT_CLASS_STRUCT *ReadAdaptedClass(TFile *fp) {
  int NumTempProtos = 0;
  int NumConfigs = 0;
  int i;
  ADAPT_CLASS_STRUCT *Class;

  // first read high level adapted class structure
  Class = new ADAPT_CLASS_STRUCT;
  // The FRead below overwrites the whole struct, including the PermProtos and
  // PermConfigs pointers the constructor just allocated; release those
  // allocations first or the clobbering leaks them.
  FreeBitVector(Class->PermProtos);
  FreeBitVector(Class->PermConfigs);
  fp->FRead(Class, sizeof(ADAPT_CLASS_STRUCT), 1);
  // The read above overwrote every member with file bytes, including the
  // pointer-bearing ones (the TempProtos list and the Config[] union
  // pointers). The destructor unconditionally destroys all MAX_NUM_CONFIGS
  // Config entries and walks TempProtos, so neutralise the file-sourced
  // pointers before any exit path can reach it; the members are then filled
  // with real allocations below.
  Class->TempProtos = NIL_LIST;
  for (i = 0; i < MAX_NUM_CONFIGS; i++) {
    Class->Config[i].Temp = nullptr;
  }

  // then read in the definitions of the permanent protos and configs
  Class->PermProtos = NewBitVector(MAX_NUM_PROTOS);
  Class->PermConfigs = NewBitVector(MAX_NUM_CONFIGS);
  fp->FRead(Class->PermProtos, sizeof(uint32_t), WordsInVectorOfSize(MAX_NUM_PROTOS));
  fp->FRead(Class->PermConfigs, sizeof(uint32_t), WordsInVectorOfSize(MAX_NUM_CONFIGS));
  // The loop above activated the Temp member of every Config[] union slot.
  // For slots the file marks permanent, activate the (aliased) Perm member so
  // the destructor reads the active union member rather than an inactive one.
  for (i = 0; i < MAX_NUM_CONFIGS; i++) {
    if (test_bit(Class->PermConfigs, i)) {
      Class->Config[i].Perm = nullptr;
    }
  }

  // then read in the list of temporary protos
  fp->FRead(&NumTempProtos, sizeof(int), 1);
  if (NumTempProtos < 0 || NumTempProtos > MAX_NUM_PROTOS) {
    tprintf("Bad read of adapted class!\n");
    delete Class;
    return nullptr;
  }
  for (i = 0; i < NumTempProtos; i++) {
    auto TempProto = new TEMP_PROTO_STRUCT;
    fp->FRead(TempProto, sizeof(TEMP_PROTO_STRUCT), 1);
    Class->TempProtos = push_last(Class->TempProtos, TempProto);
  }

  // then read in the adapted configs
  fp->FRead(&NumConfigs, sizeof(int), 1);
  // NumConfigs is used as a loop bound that writes into the fixed-size
  // Config[] array, so reject a corrupt or malicious file instead of
  // writing out of bounds.
  if (NumConfigs < 0 || NumConfigs > MAX_NUM_CONFIGS) {
    tprintf("Bad read of adapted class!\n");
    delete Class;
    return nullptr;
  }
  for (i = 0; i < NumConfigs; i++) {
    if (test_bit(Class->PermConfigs, i)) {
      Class->Config[i].Perm = ReadPermConfig(fp);
    } else {
      Class->Config[i].Temp = ReadTempConfig(fp);
    }
  }

  return (Class);

} /* ReadAdaptedClass */

/*---------------------------------------------------------------------------*/
/**
 * Read a set of adapted templates from file and return
 * a ptr to the templates.
 *
 * @param fp open text file to read adapted templates from
 * @return Ptr to adapted templates read from file.
 *
 * @note Globals: none
 */
ADAPT_TEMPLATES_STRUCT *Classify::ReadAdaptedTemplates(TFile *fp) {
  auto Templates = new ADAPT_TEMPLATES_STRUCT;

  // first read in the high level adaptive template struct
  const size_t ReadCount = fp->FRead(Templates, sizeof(ADAPT_TEMPLATES_STRUCT), 1);
  // The read above overwrote every member with file bytes, including the
  // Templates pointer and the Class[] array. ~ADAPT_TEMPLATES_STRUCT reads
  // Templates->NumClasses through Templates and deletes each Class[] entry,
  // so neutralise the file-sourced pointers before the reject path below can
  // reach the destructor; they are then filled with real allocations.
  Templates->Templates = nullptr;
  for (unsigned i = 0; i < MAX_NUM_CLASSES; i++) {
    Templates->Class[i] = nullptr;
  }
  if (ReadCount != 1) {
    tprintf("Bad read of adapted templates!\n");
    delete Templates;
    return nullptr;
  }

  // then read in the basic integer templates
  Templates->Templates = ReadIntTemplates(fp);
  if (Templates->Templates == nullptr) {
    delete Templates;
    return nullptr;
  }

  // then read in the adaptive info for each class
  for (unsigned i = 0; i < (Templates->Templates)->NumClasses; i++) {
    Templates->Class[i] = ReadAdaptedClass(fp);
    if (Templates->Class[i] == nullptr) {
      tprintf("Bad read of adapted templates (class %u)!\n", i);
      delete Templates;
      return nullptr;
    }
  }
  return (Templates);
} /* ReadAdaptedTemplates */

/*---------------------------------------------------------------------------*/
/**
 * Read a permanent configuration description from file
 * and return a ptr to it.
 *
 * @param fp open file to read permanent config from
 * @return Ptr to new permanent configuration description.
 *
 * @note Globals: none
 */
PERM_CONFIG_STRUCT *ReadPermConfig(TFile *fp) {
  auto Config = new PERM_CONFIG_STRUCT;
  uint8_t NumAmbigs;
  fp->FRead(&NumAmbigs, sizeof(NumAmbigs), 1);
  Config->Ambigs = new UNICHAR_ID[NumAmbigs + 1];
  fp->FRead(Config->Ambigs, sizeof(UNICHAR_ID), NumAmbigs);
  Config->Ambigs[NumAmbigs] = -1;
  fp->FRead(&(Config->FontinfoId), sizeof(int), 1);

  return (Config);

} /* ReadPermConfig */

/*---------------------------------------------------------------------------*/
/**
 * Read a temporary configuration description from file
 * and return a ptr to it.
 *
 * @param fp open file to read temporary config from
 * @return Ptr to new temporary configuration description.
 *
 * @note Globals: none
 */
TEMP_CONFIG_STRUCT *ReadTempConfig(TFile *fp) {
  auto Config = new TEMP_CONFIG_STRUCT;
  fp->FRead(Config, sizeof(TEMP_CONFIG_STRUCT), 1);

  Config->Protos = NewBitVector(Config->ProtoVectorSize * BITSINLONG);
  fp->FRead(Config->Protos, sizeof(uint32_t), Config->ProtoVectorSize);

  return (Config);

} /* ReadTempConfig */

/*---------------------------------------------------------------------------*/
/**
 * This routine writes a binary representation of Class
 * to File.
 *
 * @param File    open file to write Class to
 * @param Class   adapted class to write to File
 * @param NumConfigs  number of configs in Class
 *
 * @note Globals: none
 */
void WriteAdaptedClass(FILE *File, ADAPT_CLASS_STRUCT *Class, int NumConfigs) {
  /* first write high level adapted class structure */
  fwrite(Class, sizeof(ADAPT_CLASS_STRUCT), 1, File);

  /* then write out the definitions of the permanent protos and configs */
  fwrite(Class->PermProtos, sizeof(uint32_t), WordsInVectorOfSize(MAX_NUM_PROTOS), File);
  fwrite(Class->PermConfigs, sizeof(uint32_t), WordsInVectorOfSize(MAX_NUM_CONFIGS), File);

  /* then write out the list of temporary protos */
  uint32_t NumTempProtos = Class->TempProtos->size();
  fwrite(&NumTempProtos, sizeof(NumTempProtos), 1, File);
  auto TempProtos = Class->TempProtos;
  iterate(TempProtos) {
    void *proto = TempProtos->node;
    fwrite(proto, sizeof(TEMP_PROTO_STRUCT), 1, File);
  }

  /* then write out the adapted configs */
  fwrite(&NumConfigs, sizeof(int), 1, File);
  for (int i = 0; i < NumConfigs; i++) {
    if (test_bit(Class->PermConfigs, i)) {
      WritePermConfig(File, Class->Config[i].Perm);
    } else {
      WriteTempConfig(File, Class->Config[i].Temp);
    }
  }

} /* WriteAdaptedClass */

/*---------------------------------------------------------------------------*/
/**
 * This routine saves Templates to File in a binary format.
 *
 * @param File    open text file to write Templates to
 * @param Templates set of adapted templates to write to File
 *
 * @note Globals: none
 */
void Classify::WriteAdaptedTemplates(FILE *File, ADAPT_TEMPLATES_STRUCT *Templates) {
  /* first write the high level adaptive template struct */
  fwrite(Templates, sizeof(ADAPT_TEMPLATES_STRUCT), 1, File);

  /* then write out the basic integer templates */
  WriteIntTemplates(File, Templates->Templates, unicharset);

  /* then write out the adaptive info for each class */
  for (unsigned i = 0; i < (Templates->Templates)->NumClasses; i++) {
    WriteAdaptedClass(File, Templates->Class[i], Templates->Templates->Class[i]->NumConfigs);
  }
} /* WriteAdaptedTemplates */

/*---------------------------------------------------------------------------*/
/**
 * This routine writes a binary representation of a
 * permanent configuration to File.
 *
 * @param File  open file to write Config to
 * @param Config  permanent config to write to File
 *
 * @note Globals: none
 */
void WritePermConfig(FILE *File, PERM_CONFIG_STRUCT *Config) {
  uint8_t NumAmbigs = 0;

  assert(Config != nullptr);
  while (Config->Ambigs[NumAmbigs] > 0) {
    ++NumAmbigs;
  }

  fwrite(&NumAmbigs, sizeof(uint8_t), 1, File);
  fwrite(Config->Ambigs, sizeof(UNICHAR_ID), NumAmbigs, File);
  fwrite(&(Config->FontinfoId), sizeof(int), 1, File);
} /* WritePermConfig */

/*---------------------------------------------------------------------------*/
/**
 * This routine writes a binary representation of a
 * temporary configuration to File.
 *
 * @param File  open file to write Config to
 * @param Config  temporary config to write to File
 *
 * @note Globals: none
 */
void WriteTempConfig(FILE *File, TEMP_CONFIG_STRUCT *Config) {
  assert(Config != nullptr);

  fwrite(Config, sizeof(TEMP_CONFIG_STRUCT), 1, File);
  fwrite(Config->Protos, sizeof(uint32_t), Config->ProtoVectorSize, File);

} /* WriteTempConfig */

} // namespace tesseract
